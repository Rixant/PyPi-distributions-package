from setuptools import setup

setup(name='math_binomial_gaussian_distribution',
      version='0.1',
      description='Gaussian distributions',
      packages=['math_binomial_gaussian_distribution'],
      author='Rishant Rokaha',
      author_email='rixantrokaha@gmail.com',
      zip_safe=False)
